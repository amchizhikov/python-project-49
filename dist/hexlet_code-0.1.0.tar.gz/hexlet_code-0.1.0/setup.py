# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain Games package ',
    'long_description': '### Code status\n[![Maintainability](https://api.codeclimate.com/v1/badges/4eba7ad5bc1a8e7f8686/maintainability)](https://codeclimate.com/github/amchizhikov/python-project-49/maintainability)\n\n\n---\n## Install\n```\ngit clone https://github.com/amchizhikov/python-project-49.git\ncd python-project-49\nmake package-install\n```\n\n\n## Description\n\n\n### Игра: "Проверка на чётность"\nСуть игры в следующем: вам показывается случайное число. Нужно ответить \'yes\', если число чётное, или \'no\' — если нечётное.\n<a href="https://asciinema.org/a/KX8GgCXniLyFjpS5WvLxzzDHr" target="_blank"><img src="https://asciinema.org/a/KX8GgCXniLyFjpS5WvLxzzDHr.svg" /></a>\n\n\n### Игра: "Калькулятор"\nСуть игры в следующем: вам показывается случайное математическое выражение, например 25 + 17, которое нужно вычислить и записать правильный ответ.\n<a href="https://asciinema.org/a/Gt2NUCfs5kMroQ9oPXmu66FTW" target="_blank"><img src="https://asciinema.org/a/Gt2NUCfs5kMroQ9oPXmu66FTW.svg" /></a>\n\n\n### Игра "НОД"\nСуть игры в следующем: вам показывается два случайных числа, например, 25 17. Вы должны вычислить и ввести наибольший общий делитель этих чисел.\n<a href="https://asciinema.org/a/fgpaGn3J3aajjQViaqqnbXREY" target="_blank"><img src="https://asciinema.org/a/fgpaGn3J3aajjQViaqqnbXREY.svg" /></a>\n\n\n### Игра "Арифметическая прогрессия"\nСуть игры в следующем: вам показывается ряд чисел, образующий арифметическую прогрессию, в которой одно из чисел заменено точками. Вы должны определить это число.\n<a href="https://asciinema.org/a/37ykhCHeKLQKCIxmFyw4jimgc" target="_blank"><img src="https://asciinema.org/a/37ykhCHeKLQKCIxmFyw4jimgc.svg" /></a>\n\n\n### Игра "Простое ли число?"\nСуть игры в следующем: вам показывается случайное число. Нужно ответить \'yes\', если число простое, или \'no\' - если сложное.\n<a href="https://asciinema.org/a/18GIQlTjUmNWEo9SksEoUoyln" target="_blank"><img src="https://asciinema.org/a/18GIQlTjUmNWEo9SksEoUoyln.svg" /></a>\n',
    'author': 'Alexander Chizhikov',
    'author_email': 'chizhik036@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/amchizhikov/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
