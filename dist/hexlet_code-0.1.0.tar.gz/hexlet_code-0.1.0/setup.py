# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '<a href="https://codeclimate.com/github/amchizhikov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4eba7ad5bc1a8e7f8686/maintainability" /></a>\n<a href="https://asciinema.org/a/KX8GgCXniLyFjpS5WvLxzzDHr" target="_blank"><img src="https://asciinema.org/a/KX8GgCXniLyFjpS5WvLxzzDHr.svg" /></a>\n<a href="https://asciinema.org/a/Gt2NUCfs5kMroQ9oPXmu66FTW" target="_blank"><img src="https://asciinema.org/a/Gt2NUCfs5kMroQ9oPXmu66FTW.svg" /></a>\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
